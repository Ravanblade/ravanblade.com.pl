<?php
	define('DB_USER', "2bdesign");
	define('DB_PASSWORD', "zaq1@WSXzleceniaWWW");
	define('DB_DATABASE', "2bdesign_rav1");
	define('DB_SERVER', "localhost");
	define('DB_PORT', "3305");
?>
