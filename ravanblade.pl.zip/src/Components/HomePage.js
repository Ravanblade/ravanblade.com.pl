import React, {Component} from 'react';
import BannerText from './BannerText'
import 'bootstrap/dist/css/bootstrap.min.css';

class HomePage extends Component {
  render() {
    return(
      <div class="container wrapper">
      <div class="row">
        <div class="col-lg-12 col-md-12 mb-12">
        </div>
      </div>
      </div>
    );
  }
}

export default HomePage;
